# CARE Practice Coach

A low-stakes formative learning application for SW 605: Technology in Social Work Practice. Students analyze one of 12 fictional scenarios through Context, Authority, Risk and reversibility, and Engagement; receive structured AI feedback; revise their professional judgment; and copy a Canvas-ready Practice Record.

## Privacy and data handling

- Use fictional course cases only.
- Never enter real client, patient, agency, field-placement, health, contact, or identifying information.
- Responses are sent to the OpenAI API to generate feedback but are not stored by this application.
- `OPENAI_API_KEY` is read only by the server-side API route. Never expose it in browser code or commit it to GitHub.

## Run locally

Requirements: Node.js 20.9 or newer and an OpenAI API key.

1. Clone the repository.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your key to `.env.local` as `OPENAI_API_KEY=...`.
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

## Deploy to Vercel

1. Import this GitHub repository into Vercel.
2. Accept the detected Next.js settings.
3. In **Project Settings → Environment Variables**, add `OPENAI_API_KEY` for Production and Preview.
4. Deploy or redeploy.

## Deploy to Netlify

1. Import this GitHub repository into Netlify.
2. Netlify will use the included `netlify.toml` and run `npm run build`.
3. In **Project configuration → Environment variables**, add `OPENAI_API_KEY` and mark it as a secret when that option is available.
4. Deploy or redeploy.

## Canvas handoff

The application includes the direct CARE Practice Record assignment URL for each module. After revising, students copy the generated record and use the displayed link to open the matching Canvas assignment.

## Configuration

- Fictional scenarios and Canvas links: `lib/cases.ts`
- CARE questions and user flow: `app/page.tsx`
- AI feedback instructions and rubric schema: `app/api/feedback/route.ts`

The current feedback model is `gpt-5-mini`. Change it in the server-side route if needed.
